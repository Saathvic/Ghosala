"use client"

import { useState } from "react"
import Link from "next/link"
import { ShoppingCart, Search, Menu, User, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { categories } from "@/lib/data"

export default function SiteHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white border-b">
      <div className="container mx-auto p-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col gap-4">
                  <Link
                    href="/"
                    className="flex items-center gap-2 font-semibold text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Leaf className="h-5 w-5 text-primary" />
                    <span>NatureHarvest</span>
                  </Link>
                  <div className="border-b my-2" />
                  <Link href="/" className="py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    Home
                  </Link>
                  <Link href="/products" className="py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    All Products
                  </Link>
                  <div className="py-2 font-medium">Categories</div>
                  {categories.map((category) => (
                    <Link
                      key={category.id}
                      href={`/category/${category.slug}`}
                      className="py-2 pl-4 hover:text-primary"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {category.name}
                    </Link>
                  ))}
                  <Link href="/cart" className="py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    Cart
                  </Link>
                  <Link href="/checkout" className="py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    Checkout
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
            <Link href="/" className="flex items-center gap-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">NatureHarvest</span>
            </Link>
          </div>

          <div className="flex-1 max-w-xl hidden md:flex relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              <Search className="h-4 w-4 text-muted-foreground" />
            </div>
            <Input className="w-full pl-10" placeholder="Search organic products..." />
            <Button className="ml-2">Search</Button>
          </div>

          <div className="flex items-center gap-4">
            <Link href="/account" className="hidden md:flex items-center gap-1">
              <div className="flex flex-col text-xs">
                <span className="text-muted-foreground">Hello, Sign in</span>
                <span className="font-semibold">Account & Lists</span>
              </div>
            </Link>
            <Link href="/account" className="md:hidden">
              <User className="h-6 w-6" />
            </Link>
            <Link href="/cart" className="flex items-center gap-1">
              <div className="relative">
                <ShoppingCart className="h-6 w-6" />
                <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  3
                </span>
              </div>
              <span className="hidden md:inline font-semibold">Cart</span>
            </Link>
          </div>
        </div>

        <div className="mt-2 md:hidden relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3">
            <Search className="h-4 w-4 text-muted-foreground" />
          </div>
          <Input className="w-full pl-10" placeholder="Search organic products..." />
        </div>

        <nav className="hidden md:flex items-center gap-6 mt-2">
          <Link href="/" className="text-sm hover:text-primary font-medium">
            Home
          </Link>
          <Link href="/products" className="text-sm hover:text-primary font-medium">
            All Products
          </Link>
          {categories.slice(0, 5).map((category) => (
            <Link key={category.id} href={`/category/${category.slug}`} className="text-sm hover:text-primary">
              {category.name}
            </Link>
          ))}
          <Link href="/cart" className="text-sm hover:text-primary font-medium">
            Cart
          </Link>
          <Link href="/checkout" className="text-sm hover:text-primary font-medium">
            Checkout
          </Link>
        </nav>
      </div>
    </header>
  )
}
