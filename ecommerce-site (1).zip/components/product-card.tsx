"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, ShoppingCart, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import RatingStars from "@/components/rating-stars"
import type { Product } from "@/lib/types"

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="group border rounded-lg overflow-hidden bg-white h-full flex flex-col"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link href={`/products/${product.id}`} className="relative block">
        <div className="aspect-square relative overflow-hidden">
          <Image
            src={isHovered && product.images.length > 1 ? product.images[1] : product.images[0]}
            alt={product.name}
            fill
            className="object-contain transition-transform group-hover:scale-105"
          />
        </div>

        {product.badge && (
          <div className="absolute top-2 left-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full flex items-center gap-1">
            <Leaf className="h-3 w-3" />
            <span>{product.badge}</span>
          </div>
        )}

        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white"
        >
          <Heart className="h-4 w-4" />
        </Button>
      </Link>

      <div className="p-4 flex-1 flex flex-col">
        <Link href={`/products/${product.id}`} className="flex-1">
          <div className="text-xs text-primary font-medium mb-1">{product.category}</div>
          <h3 className="font-medium line-clamp-2 mb-1 hover:text-primary transition-colors">{product.name}</h3>

          <div className="flex items-center gap-1 mb-2">
            <RatingStars rating={product.rating} />
            <span className="text-xs text-gray-500">({product.reviewCount})</span>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <span className="font-bold text-lg">${product.price.toFixed(2)}</span>
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">${product.originalPrice.toFixed(2)}</span>
            )}
          </div>
        </Link>

        <Button className="w-full gap-2">
          <ShoppingCart className="h-4 w-4" />
          Add to Cart
        </Button>
      </div>
    </div>
  )
}
