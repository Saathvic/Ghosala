import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import ProductCard from "@/components/product-card"
import ProductCardSkeleton from "@/components/product-card-skeleton"
import { products } from "@/lib/data"

export default function ProductsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="text-sm text-gray-500 hover:text-primary">
          Home
        </Link>
        <ChevronRight className="h-4 w-4 text-gray-500" />
        <span className="text-sm font-medium">All Products</span>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-64 shrink-0">
          <div className="bg-white p-4 border rounded-lg">
            <h3 className="font-semibold mb-3">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-sm hover:text-primary">
                  Organic Food (24)
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm hover:text-primary">
                  Natural Skincare (18)
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm hover:text-primary">
                  Eco-Friendly Home (15)
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm hover:text-primary">
                  Supplements (12)
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm hover:text-primary">
                  Organic Beverages (9)
                </Link>
              </li>
            </ul>

            <div className="mt-6">
              <h3 className="font-semibold mb-3">Price Range</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="price-1" className="mr-2" />
                  <label htmlFor="price-1" className="text-sm">
                    Under $15
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-2" className="mr-2" />
                  <label htmlFor="price-2" className="text-sm">
                    $15 to $25
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-3" className="mr-2" />
                  <label htmlFor="price-3" className="text-sm">
                    $25 to $50
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-4" className="mr-2" />
                  <label htmlFor="price-4" className="text-sm">
                    $50 to $100
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-5" className="mr-2" />
                  <label htmlFor="price-5" className="text-sm">
                    $100 & Above
                  </label>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="font-semibold mb-3">Certifications</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="cert-1" className="mr-2" />
                  <label htmlFor="cert-1" className="text-sm">
                    USDA Organic
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="cert-2" className="mr-2" />
                  <label htmlFor="cert-2" className="text-sm">
                    Non-GMO Project
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="cert-3" className="mr-2" />
                  <label htmlFor="cert-3" className="text-sm">
                    Fair Trade
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="cert-4" className="mr-2" />
                  <label htmlFor="cert-4" className="text-sm">
                    B Corp
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="cert-5" className="mr-2" />
                  <label htmlFor="cert-5" className="text-sm">
                    Cruelty Free
                  </label>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="font-semibold mb-3">Customer Rating</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="rating-4" className="mr-2" />
                  <label htmlFor="rating-4" className="text-sm">
                    4★ & Above
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="rating-3" className="mr-2" />
                  <label htmlFor="rating-3" className="text-sm">
                    3★ & Above
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="rating-2" className="mr-2" />
                  <label htmlFor="rating-2" className="text-sm">
                    2★ & Above
                  </label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="rating-1" className="mr-2" />
                  <label htmlFor="rating-1" className="text-sm">
                    1★ & Above
                  </label>
                </div>
              </div>
            </div>
          </div>
        </aside>

        <div className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">All Products</h1>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">Sort by:</span>
              <select className="text-sm border rounded-md p-1">
                <option>Featured</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Customer Rating</option>
                <option>Newest Arrivals</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.slice(0, 7).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
            <ProductCardSkeleton />
          </div>

          <div className="flex items-center justify-center gap-2 mt-8">
            <Button variant="outline" size="icon">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="h-8 w-8">
              1
            </Button>
            <Button variant="outline" className="h-8 w-8">
              2
            </Button>
            <Button variant="outline" className="h-8 w-8">
              3
            </Button>
            <span className="mx-1">...</span>
            <Button variant="outline" className="h-8 w-8">
              10
            </Button>
            <Button variant="outline" size="icon">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
