import Link from "next/link"
import { ChevronRight, Minus, Plus, Star, Truck, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProductImageGallery from "@/components/product-image-gallery"
import RatingStars from "@/components/rating-stars"
import { products } from "@/lib/data"

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  // In a real app, you would fetch the product by ID from an API
  const product = products.find((p) => p.id === params.id) || products[0]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="text-sm text-gray-500 hover:text-primary">
          Home
        </Link>
        <ChevronRight className="h-4 w-4 text-gray-500" />
        <Link href="/products" className="text-sm text-gray-500 hover:text-primary">
          Products
        </Link>
        <ChevronRight className="h-4 w-4 text-gray-500" />
        <span className="text-sm font-medium">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <ProductImageGallery images={product.images} />
        </div>

        <div className="lg:col-span-2">
          <div className="lg:grid lg:grid-cols-2 gap-8">
            <div>
              <div className="text-sm text-primary font-medium mb-1">{product.category}</div>
              <h1 className="text-2xl font-bold mb-2">{product.name}</h1>

              <div className="flex items-center gap-2 mb-4">
                <RatingStars rating={product.rating} />
                <span className="text-sm text-gray-500">({product.reviewCount} reviews)</span>
              </div>

              <div className="mb-6">
                <div className="text-2xl font-bold text-primary mb-1">${product.price.toFixed(2)}</div>
                {product.originalPrice && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500 line-through">${product.originalPrice.toFixed(2)}</span>
                    <span className="text-sm text-green-600">
                      Save ${(product.originalPrice - product.price).toFixed(2)}
                    </span>
                  </div>
                )}
              </div>

              <div className="mb-6">
                <h3 className="font-semibold mb-2">About this item:</h3>
                <ul className="list-disc pl-5 space-y-1">
                  {product.features.map((feature, index) => (
                    <li key={index} className="text-sm">
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="border rounded-lg p-4 bg-secondary/30">
              <div className="text-xl font-bold mb-2">${product.price.toFixed(2)}</div>

              <div className="flex items-center gap-2 text-sm mb-4">
                <Truck className="h-4 w-4 text-primary" />
                <span>
                  <span className="font-medium">FREE delivery</span> Tomorrow, May 21
                </span>
              </div>

              <div className="text-green-600 font-medium mb-4 flex items-center gap-1">
                <ShieldCheck className="h-4 w-4" />
                <span>In Stock</span>
              </div>

              <div className="flex items-center mb-6">
                <span className="mr-3">Qty:</span>
                <div className="flex items-center border rounded-md">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Minus className="h-3 w-3" />
                  </Button>
                  <span className="w-8 text-center">1</span>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <Button className="w-full">Add to Cart</Button>
                <Button variant="secondary" className="w-full">
                  Buy Now
                </Button>
              </div>

              <div className="mt-4 text-sm">
                <div className="flex items-start gap-2 mb-2">
                  <span className="font-medium">Ships from</span>
                  <span>NatureHarvest.com</span>
                </div>
                <div className="flex items-start gap-2 mb-2">
                  <span className="font-medium">Sold by</span>
                  <span>NatureHarvest LLC</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-medium">Returns</span>
                  <span>Eligible for Return, Refund or Replacement within 30 days</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <Tabs defaultValue="description">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="specifications">Specifications</TabsTrigger>
                <TabsTrigger value="reviews">Customer Reviews</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-4">
                <div className="prose max-w-none">
                  <p>{product.description}</p>
                </div>
              </TabsContent>
              <TabsContent value="specifications" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-semibold mb-2">Product Details</h3>
                    <table className="w-full text-sm">
                      <tbody>
                        {product.specifications.slice(0, 5).map((spec, index) => (
                          <tr key={index} className={index % 2 === 0 ? "bg-secondary/50" : ""}>
                            <td className="py-2 px-3 font-medium">{spec.name}</td>
                            <td className="py-2 px-3">{spec.value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Additional Information</h3>
                    <table className="w-full text-sm">
                      <tbody>
                        {product.specifications.slice(5, 10).map((spec, index) => (
                          <tr key={index} className={index % 2 === 0 ? "bg-secondary/50" : ""}>
                            <td className="py-2 px-3 font-medium">{spec.name}</td>
                            <td className="py-2 px-3">{spec.value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="mt-4">
                <div className="flex flex-col md:flex-row gap-8">
                  <div className="md:w-64">
                    <div className="text-5xl font-bold">{product.rating.toFixed(1)}</div>
                    <RatingStars rating={product.rating} />
                    <div className="text-sm text-gray-500 mt-1">{product.reviewCount} ratings</div>

                    <div className="mt-4 space-y-2">
                      {[5, 4, 3, 2, 1].map((star) => (
                        <div key={star} className="flex items-center gap-2">
                          <span className="text-sm w-3">{star}</span>
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-yellow-400 h-2 rounded-full"
                              style={{
                                width: `${star === 5 ? 70 : star === 4 ? 20 : star === 3 ? 5 : star === 2 ? 3 : 2}%`,
                              }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-500">
                            {star === 5 ? 70 : star === 4 ? 20 : star === 3 ? 5 : star === 3 ? 3 : 2}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex-1">
                    <h3 className="font-semibold mb-4">Top reviews</h3>
                    <div className="space-y-6">
                      {[1, 2, 3].map((review) => (
                        <div key={review} className="border-b pb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">{["JD", "SM", "AK"][review - 1]}</span>
                            </div>
                            <span className="font-medium">{["Jane Doe", "Sam Miller", "Alex Kim"][review - 1]}</span>
                          </div>
                          <div className="flex items-center gap-2 mb-2">
                            <RatingStars rating={[5, 4, 5][review - 1]} />
                            <span className="text-sm font-medium">
                              {["Love this product!", "Good quality", "Highly recommended"][review - 1]}
                            </span>
                          </div>
                          <div className="text-sm text-gray-500 mb-2">
                            Verified Purchase on {["May 15, 2025", "May 10, 2025", "May 5, 2025"][review - 1]}
                          </div>
                          <p className="text-sm">
                            {
                              [
                                "This organic product exceeded my expectations. The quality is outstanding and it's so much better than conventional alternatives. Will definitely buy again!",
                                "Good organic product for the price. It has most of the benefits I was looking for, though there are a few minor issues. Overall satisfied with my purchase.",
                                "I've tried several similar organic products and this is by far the best one. The quality is exceptional and you can really taste the difference. Highly recommended!",
                              ][review - 1]
                            }
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
